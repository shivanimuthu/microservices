import json
import requests

def lambda_handler(event, context):
    print("Hello from Microserivce - 2!")
    resp = requests.get('https://h1amwlhj24.execute-api.us-east-1.amazonaws.com/microservice-3')
    if resp.status_code != 200:
        # This means something went wrong.
        raise ApiError('GET /microservice-3 {}'.format(resp.status_code))
    return {
        'statusCode': 200,
        'body': resp.json()
    }



