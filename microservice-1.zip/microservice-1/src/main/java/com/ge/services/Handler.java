package com.ge.services;

import com.amazonaws.services.lambda.runtime.Context;
import com.amazonaws.services.lambda.runtime.RequestHandler;
import com.amazonaws.services.lambda.runtime.LambdaLogger;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpMethod;
import org.springframework.web.client.RestTemplate;

import java.util.Map;


public class Handler implements RequestHandler<Map<String,Object>, String>{



  @Override
  public String handleRequest(Map<String,Object> event, Context context)
  {

    RestTemplate restTemplate=new RestTemplate();
    LambdaLogger logger = context.getLogger();
    //String response = "200 OK";
    logger.log("In microservice-1");
    String baseUrl = "https://njfmvearia.execute-api.us-east-1.amazonaws.com/microservice-2";
    logger.log("Calling microservice  2 with base url : "+baseUrl);
    String response = (String) restTemplate.exchange(baseUrl, HttpMethod.GET, null, String.class).getBody();
    logger.log("The response received by method1 is " + response);
    return response;
  }
}